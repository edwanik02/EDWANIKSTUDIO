import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { prisma } from '@/lib/prisma'

export default async function CustomerLayout({ children }: { children: React.ReactNode }) {
  const settings = await prisma.siteSettings.findFirst()
  return (
    <>
      <Navbar siteName={settings?.siteName ?? 'FunziToys'} logoUrl={settings?.logoUrl ?? undefined} />
      <main className="pt-16 min-h-screen">{children}</main>
      <Footer settings={settings ? { id: settings.id, siteName: settings.siteName, tagline: settings.tagline ?? undefined, logoUrl: settings.logoUrl ?? undefined, primaryColor: settings.primaryColor, whatsappNum: settings.whatsappNum ?? undefined, supportEmail: settings.supportEmail ?? undefined } : null} />
    </>
  )
}
